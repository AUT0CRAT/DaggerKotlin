package parkar.alim.daggerwithkotlin.annotations


import javax.inject.Qualifier

/**
 * Created by Alim.Parkar on 7/5/2017.
 */
@Qualifier
@Retention(AnnotationRetention.RUNTIME)
annotation class DatabaseInfo
