package parkar.alim.daggerwithkotlin.annotations


import java.lang.annotation.RetentionPolicy
import javax.inject.Qualifier

/**
 * Created by Alim.Parkar on 7/5/2017.
 */
@Qualifier
@Retention(AnnotationRetention.RUNTIME)
annotation class ActivityContext
