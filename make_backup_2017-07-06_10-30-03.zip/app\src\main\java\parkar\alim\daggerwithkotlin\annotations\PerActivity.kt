package parkar.alim.daggerwithkotlin.annotations

import javax.inject.Scope

/**
 * Created by Alim.Parkar on 7/5/2017.
 */
@Scope
@Retention(AnnotationRetention.RUNTIME)
annotation class PerActivity
